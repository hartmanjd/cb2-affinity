Original metadata and notebook snapshots before descriptive renaming. These are historical records, not active paths. Scientific data and model bytes were not changed.
